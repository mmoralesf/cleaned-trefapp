
# 🔐 Admin & Agent Access Credentials

These are sample credentials for testing login functionality.

## Admin Account
- **Email**: admin@trefa.mx
- **Password**: Admin1234

## Sales Agent Account
- **Email**: agente@trefa.mx
- **Password**: Agente1234

> ⚠️ These are dummy credentials. You’ll need to create them in Supabase Auth or mock them in your login logic.
