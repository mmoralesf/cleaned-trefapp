
export interface Auto {
  id: string;
  ordencompra: string;
  marca: string;
  modelo: string;
  año: number;
  precio: number;
  imagenUrl?: string;
  status?: string;
}
